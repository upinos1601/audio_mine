package umn.ac.audiomine;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Login extends AppCompatActivity implements View.OnClickListener {

    private TextView regr;
    private Button btnLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnLog = findViewById(R.id.btnLogin);
        regr = findViewById(R.id.txtdonthavelogin);

    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        switch(v.getId()){
            case R.id.btnLogin:
                intent = new Intent(this,MainActivity.class);
                break;
            case R.id.txtdonthavelogin:
                intent = new Intent(this,RegisterUser.class);
                break;

        }
        if (null!=intent) startActivity(intent);
    }

}