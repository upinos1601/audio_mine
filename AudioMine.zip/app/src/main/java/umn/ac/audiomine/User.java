package umn.ac.audiomine;

public class User {

    public String nama, email;

    public User(String nama, String email, String password) {

    }

    public User (String nama, String email){
        this.nama = nama;
        this.email = email;
    }

}
